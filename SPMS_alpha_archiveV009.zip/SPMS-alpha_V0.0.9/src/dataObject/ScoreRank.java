package dataObject;

public enum ScoreRank {
Unrank,P,A,B,C,D,F
}
