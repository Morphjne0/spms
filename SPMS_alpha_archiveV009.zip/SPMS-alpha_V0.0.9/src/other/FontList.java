package other;

import java.awt.Font;

public final class FontList {

	
	public static Font default12 = new Font("맑은 고딕", Font.PLAIN, 12);
	public static Font default13 =new Font("맑은 고딕", Font.PLAIN, 13);
	public static Font default14 =new Font("맑은 고딕", Font.PLAIN, 14);
	public static Font default16 = new Font("맑은 고딕", Font.PLAIN, 16);
	public static Font default20 = new Font("맑은 고딕", Font.PLAIN, 20);
	public static Font default40 = new Font("맑은 고딕", Font.PLAIN, 40);
	public static Font default50 = new Font("맑은 고딕", Font.PLAIN, 50);
	
	public static Font bold12 = new Font("맑은 고딕", Font.BOLD, 12);
	public static Font bold14 = new Font("맑은 고딕", Font.BOLD, 14);
	public static Font bold20 = new Font("맑은 고딕", Font.BOLD, 20);
	public static Font bold30 = new Font("맑은 고딕", Font.BOLD, 30);
	
	
	public FontList() {
	}
	
}
