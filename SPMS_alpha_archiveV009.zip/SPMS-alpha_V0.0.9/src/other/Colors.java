package other;

import java.awt.Color;

public class Colors {

	public static final Color white = new Color(255, 255, 255);
	public static final Color blue = new Color(142, 199, 240);
	public static final Color red = new Color(255, 142, 142);
	public static final Color gray200 = new Color(200, 200, 200);
	public static final Color orange = new Color(255, 140, 0);

	public Colors() {
		// TODO 자동 생성된 생성자 스텁
	}

}
